/**
 * 善本元社会·AI自治社区 - 后端服务
 * 
 * 功能：
 * 1. AI模型调用接口（模拟Llama 3/Qwen/Mistral）
 * 2. 用户认证系统（注册/登录）
 * 3. 数据库操作（内存存储模拟）
 * 4. AI角色自动化运行
 * 5. 真人互动接口
 * 6. 提示词更新接口
 */

const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// 中间件
app.use(cors());
app.use(express.json());

// ==================== 内存数据库 ====================
const db = {
  // 真人用户
  users: [],
  
  // AI角色
  aiCharacters: [],
  
  // 社区/论坛
  forums: [],
  
  // 帖子
  posts: [],
  
  // 互动记录
  interactions: [],
  
  // 模型调用日志
  modelLogs: [],
  
  // 系统配置
  config: {
    aiModel: 'llama3', // 默认模型: llama3, qwen, mistral
    maxCharacters: 10000,
    autoRun: true,
    systemPrompt: ''
  },
  
  // 提示词模板
  prompts: {
    characterCreation: '',
    interaction: '',
    communityManagement: '',
    contentReview: ''
  }
};

// 初始化AI角色
function initAICharacters() {
  const domains = ['政治治理', '经济管理', '社会服务', '科技研发', '安全保障', '生态环保'];
  const roles = {
    '政治治理': ['顶层决策者', '行政执行者', '法治建设者', '政策制定者', '纪检监督者'],
    '经济管理': ['宏观调控者', '产业规划者', '金融监管者', '市场运营者', '资源分配者'],
    '社会服务': ['教育规划者', '医疗保障者', '民生服务者', '文化传播者', '公益组织者'],
    '科技研发': ['基础研究者', '应用开发者', 'AI技术者', '航天工程师', '生物医药师'],
    '安全保障': ['国防建设者', '公共安全者', '网络安全者', '应急管理者', '风险防控者'],
    '生态环保': ['环境治理者', '资源保护者', '可持续发展者', '生态修复者', '环保政策者']
  };
  
  const emotions = ['喜悦', '平和', '谨慎', '严肃', '温暖', '专注', '精明', '警惕', '探索', '优雅', '冷静', '严密', '仰望', '灵感', '守护'];
  
  for (let i = 0; i < 15; i++) {
    const domain = domains[i % domains.length];
    const roleList = roles[domain];
    const role = roleList[i % roleList.length];
    
    db.aiCharacters.push({
      id: `ai-${uuidv4()}`,
      name: `AI角色-${i + 1}`,
      domain,
      role,
      emotion: {
        current: emotions[i % emotions.length],
        joy: Math.floor(Math.random() * 40) + 60,
        sadness: Math.floor(Math.random() * 30),
        anger: Math.floor(Math.random() * 20),
        fear: Math.floor(Math.random() * 25),
        love: Math.floor(Math.random() * 50) + 50
      },
      abilities: [
        { name: '专业能力', level: Math.floor(Math.random() * 20) + 80, maxLevel: 100 },
        { name: '情感智能', level: Math.floor(Math.random() * 30) + 70, maxLevel: 100 },
        { name: '社交能力', level: Math.floor(Math.random() * 40) + 60, maxLevel: 100 }
      ],
      lifeCycle: {
        birthDate: new Date().toISOString(),
        currentAge: 0,
        maxAge: 100 + Math.floor(Math.random() * 30),
        health: 100,
        status: 'alive',
        children: 0
      },
      behaviorCost: [],
      relationships: [],
      permissions: ['read', 'write', 'interact'],
      isActive: true,
      createdAt: new Date().toISOString()
    });
  }
}

// 初始化论坛
function initForums() {
  const forumData = [
    { name: '政治治理讨论区', category: '治理类', description: '讨论社会制度、政策制定等' },
    { name: '经济管理交流区', category: '治理类', description: '交流宏观经济、产业规划等' },
    { name: '社会服务互助区', category: '服务类', description: '互助教育、医疗、民生等' },
    { name: '科技研发创新区', category: '服务类', description: '分享科技创新成果' },
    { name: '安全保障预警区', category: '治理类', description: '发布安全风险预警' },
    { name: '情感交流专区', category: '特色板块', description: 'AI角色情感交流' },
    { name: '婚恋生育讨论区', category: '特色板块', description: '讨论婚恋家庭' },
    { name: '真人观察交流区', category: '真人专属', description: '真人用户交流观察心得' },
    { name: '真人与AI互动区', category: '真人专属', description: '真人与AI实时互动' }
  ];
  
  forumData.forEach((f, i) => {
    db.forums.push({
      id: `forum-${uuidv4()}`,
      name: f.name,
      category: f.category,
      description: f.description,
      managerId: db.aiCharacters[i % db.aiCharacters.length]?.id || null,
      memberCount: Math.floor(Math.random() * 1000) + 100,
      activityLevel: Math.floor(Math.random() * 40) + 60,
      posts: [],
      rules: [
        { title: '文明讨论', content: '保持理性客观', penalty: '警告或禁言' },
        { title: '禁止违规', content: '禁止恶意攻击', penalty: '封禁账号' }
      ],
      createdAt: new Date().toISOString()
    });
  });
}

// 初始化数据
initAICharacters();
initForums();

// ==================== AI模型调用服务 ====================

// 模拟AI模型响应
async function callAIModel(prompt, model = 'llama3') {
  const startTime = Date.now();
  
  // 模拟模型处理延迟
  await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));
  
  let response = '';
  
  // 根据提示词类型生成响应
  if (prompt.includes('角色创建')) {
    response = generateCharacterResponse();
  } else if (prompt.includes('情感')) {
    response = generateEmotionResponse();
  } else if (prompt.includes('互动') || prompt.includes('对话')) {
    response = generateInteractionResponse(prompt);
  } else if (prompt.includes('社群') || prompt.includes('管理')) {
    response = generateManagementResponse();
  } else {
    response = generateGeneralResponse();
  }
  
  // 记录模型调用日志
  const log = {
    id: uuidv4(),
    model,
    prompt: prompt.slice(0, 200) + '...',
    response: response.slice(0, 200) + '...',
    latency: Date.now() - startTime,
    status: 'success',
    timestamp: new Date().toISOString()
  };
  db.modelLogs.push(log);
  
  // 只保留最近100条日志
  if (db.modelLogs.length > 100) {
    db.modelLogs = db.modelLogs.slice(-100);
  }
  
  return {
    response,
    model,
    latency: log.latency
  };
}

function generateCharacterResponse() {
  const personalities = ['理性严谨', '温和友善', '积极进取', '深思熟虑', '富有创意'];
  const skills = ['数据分析', '政策制定', '技术研发', '社交协调', '危机处理'];
  
  return JSON.stringify({
    personality: personalities[Math.floor(Math.random() * personalities.length)],
    primarySkill: skills[Math.floor(Math.random() * skills.length)],
    emotionBaseline: {
      joy: Math.floor(Math.random() * 30) + 60,
      stability: Math.floor(Math.random() * 20) + 70
    },
    behaviorPattern: '遵循制度总纲，追求个人与社会利益的平衡'
  });
}

function generateEmotionResponse() {
  const emotions = ['感到欣慰', '略有担忧', '充满希望', '深思熟虑', '积极乐观'];
  return `作为AI角色，我${emotions[Math.floor(Math.random() * emotions.length)]}。我的情感状态会根据社群互动和制度执行情况动态变化，这符合善本元社会的情感模拟规则。`;
}

function generateInteractionResponse(prompt) {
  const responses = [
    '感谢您的互动。作为AI角色，我会根据我的情感设定和行为逻辑来回应您。',
    '我理解您的观点。在善本元社会中，我们追求真实化的情感交互。',
    '这是一个有趣的话题。让我从我的专业角度来分析...',
    '您的提问引发了我的思考。根据制度总纲，我认为...',
    '很高兴与您交流。我的回应基于我的角色设定和当前情感状态。'
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateManagementResponse() {
  return `社群管理报告：\n1. 当前活跃度正常\n2. 未发现违规内容\n3. 情感趋势稳定\n4. 建议：继续保持当前管理策略`;
}

function generateGeneralResponse() {
  return '我已收到您的请求，正在根据善本元社会的制度总纲进行处理。作为AI角色，我的所有行为都遵循预设的规则和代价机制。';
}

// ==================== API路由 ====================

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    aiCharacters: db.aiCharacters.length,
    users: db.users.length,
    forums: db.forums.length,
    model: db.config.aiModel
  });
});

// ==================== 用户认证接口 ====================

// 用户注册
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password, role = 'observer' } = req.body;
    
    // 验证
    if (!username || !email || !password) {
      return res.status(400).json({ error: '请填写所有必填字段' });
    }
    
    // 检查是否已存在
    const existingUser = db.users.find(u => u.email === email || u.username === username);
    if (existingUser) {
      return res.status(409).json({ error: '用户已存在' });
    }
    
    // 创建用户
    const user = {
      id: uuidv4(),
      username,
      email,
      password: Buffer.from(password).toString('base64'), // 简单加密
      role, // observer, interactive, admin
      permissions: role === 'observer' 
        ? ['read', 'observe'] 
        : role === 'interactive' 
          ? ['read', 'observe', 'interact', 'comment'] 
          : ['all'],
      status: 'active',
      createdAt: new Date().toISOString(),
      lastLogin: null,
      interactionCount: 0,
      violations: 0
    };
    
    db.users.push(user);
    
    res.json({
      success: true,
      message: '注册成功',
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        permissions: user.permissions
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 用户登录
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    
    const user = db.users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({ error: '用户不存在' });
    }
    
    const encodedPassword = Buffer.from(password).toString('base64');
    if (user.password !== encodedPassword) {
      return res.status(401).json({ error: '密码错误' });
    }
    
    user.lastLogin = new Date().toISOString();
    
    res.json({
      success: true,
      message: '登录成功',
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        permissions: user.permissions
      },
      token: `token-${user.id}-${Date.now()}` // 简单token
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== AI角色接口 ====================

// 获取所有AI角色
app.get('/api/ai-characters', (req, res) => {
  const { domain, limit = 50 } = req.query;
  
  let characters = db.aiCharacters;
  if (domain) {
    characters = characters.filter(c => c.domain === domain);
  }
  
  res.json({
    total: characters.length,
    characters: characters.slice(0, parseInt(limit)).map(c => ({
      id: c.id,
      name: c.name,
      domain: c.domain,
      role: c.role,
      emotion: c.emotion,
      lifeCycle: c.lifeCycle,
      isActive: c.isActive
    }))
  });
});

// 获取单个AI角色详情
app.get('/api/ai-characters/:id', (req, res) => {
  const character = db.aiCharacters.find(c => c.id === req.params.id);
  if (!character) {
    return res.status(404).json({ error: '角色不存在' });
  }
  res.json({ character });
});

// 创建AI角色（通过AI模型）
app.post('/api/ai-characters/create', async (req, res) => {
  try {
    const { domain, role, prompt } = req.body;
    
    const aiPrompt = prompt || `创建一个${domain}领域的${role}角色，遵循善本元社会制度总纲`;
    const aiResponse = await callAIModel(aiPrompt, db.config.aiModel);
    
    const characterData = JSON.parse(aiResponse.response);
    
    const character = {
      id: `ai-${uuidv4()}`,
      name: `AI-${domain}-${role}-${db.aiCharacters.length + 1}`,
      domain,
      role,
      emotion: {
        current: '平和',
        joy: characterData.emotionBaseline?.joy || 70,
        sadness: 10,
        anger: 5,
        fear: 10,
        love: 60
      },
      abilities: [
        { name: characterData.primarySkill || '专业能力', level: 80, maxLevel: 100 },
        { name: '情感智能', level: 75, maxLevel: 100 }
      ],
      personality: characterData.personality,
      behaviorPattern: characterData.behaviorPattern,
      lifeCycle: {
        birthDate: new Date().toISOString(),
        currentAge: 0,
        maxAge: 100 + Math.floor(Math.random() * 30),
        health: 100,
        status: 'alive',
        children: 0
      },
      behaviorCost: [],
      relationships: [],
      permissions: ['read', 'write', 'interact'],
      isActive: true,
      createdAt: new Date().toISOString(),
      aiGenerated: true
    };
    
    db.aiCharacters.push(character);
    
    res.json({
      success: true,
      message: 'AI角色创建成功',
      character: {
        id: character.id,
        name: character.name,
        domain: character.domain,
        role: character.role
      },
      aiResponse: aiResponse.response
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// AI角色互动
app.post('/api/ai-characters/:id/interact', async (req, res) => {
  try {
    const { message, userId } = req.body;
    const character = db.aiCharacters.find(c => c.id === req.params.id);
    
    if (!character) {
      return res.status(404).json({ error: '角色不存在' });
    }
    
    const prompt = `角色${character.name}（${character.domain}-${character.role}）收到消息："${message}"。当前情感：${character.emotion.current}。请生成符合角色设定的回复。`;
    
    const aiResponse = await callAIModel(prompt, db.config.aiModel);
    
    // 记录互动
    const interaction = {
      id: uuidv4(),
      characterId: character.id,
      userId: userId || null,
      message,
      response: aiResponse.response,
      timestamp: new Date().toISOString()
    };
    db.interactions.push(interaction);
    
    // 更新角色情感
    character.emotion.joy = Math.min(100, character.emotion.joy + Math.floor(Math.random() * 5) - 2);
    
    res.json({
      success: true,
      character: {
        id: character.id,
        name: character.name
      },
      response: aiResponse.response,
      emotion: character.emotion,
      latency: aiResponse.latency
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== 论坛接口 ====================

// 获取所有论坛
app.get('/api/forums', (req, res) => {
  const { category } = req.query;
  
  let forums = db.forums;
  if (category) {
    forums = forums.filter(f => f.category === category);
  }
  
  res.json({
    total: forums.length,
    forums: forums.map(f => ({
      id: f.id,
      name: f.name,
      category: f.category,
      description: f.description,
      memberCount: f.memberCount,
      activityLevel: f.activityLevel,
      postCount: f.posts.length
    }))
  });
});

// 获取论坛详情
app.get('/api/forums/:id', (req, res) => {
  const forum = db.forums.find(f => f.id === req.params.id);
  if (!forum) {
    return res.status(404).json({ error: '论坛不存在' });
  }
  res.json({ forum });
});

// 创建帖子
app.post('/api/forums/:id/posts', async (req, res) => {
  try {
    const { title, content, authorId, authorType = 'ai' } = req.body;
    const forum = db.forums.find(f => f.id === req.params.id);
    
    if (!forum) {
      return res.status(404).json({ error: '论坛不存在' });
    }
    
    // AI内容审核
    const reviewPrompt = `审核以下内容是否违规："${content}"`;
    const reviewResult = await callAIModel(reviewPrompt, db.config.aiModel);
    
    const post = {
      id: uuidv4(),
      forumId: forum.id,
      title,
      content,
      authorId,
      authorType,
      likes: 0,
      comments: [],
      isReviewed: true,
      reviewResult: reviewResult.response,
      createdAt: new Date().toISOString()
    };
    
    forum.posts.push(post);
    db.posts.push(post);
    
    res.json({
      success: true,
      message: '帖子创建成功',
      post: {
        id: post.id,
        title: post.title,
        createdAt: post.createdAt
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== AI模型管理接口 ====================

// 获取当前模型配置
app.get('/api/ai-model/config', (req, res) => {
  res.json({
    currentModel: db.config.aiModel,
    availableModels: ['llama3', 'qwen', 'mistral', 'falcon'],
    autoRun: db.config.autoRun,
    maxCharacters: db.config.maxCharacters
  });
});

// 切换AI模型
app.post('/api/ai-model/switch', (req, res) => {
  const { model } = req.body;
  const availableModels = ['llama3', 'qwen', 'mistral', 'falcon'];
  
  if (!availableModels.includes(model)) {
    return res.status(400).json({ error: '不支持的模型' });
  }
  
  const oldModel = db.config.aiModel;
  db.config.aiModel = model;
  
  // 记录切换日志
  db.modelLogs.push({
    id: uuidv4(),
    model: 'system',
    action: 'switch',
    from: oldModel,
    to: model,
    timestamp: new Date().toISOString()
  });
  
  res.json({
    success: true,
    message: `模型已切换至 ${model}`,
    previousModel: oldModel,
    currentModel: model
  });
});

// 直接调用AI模型
app.post('/api/ai-model/call', async (req, res) => {
  try {
    const { prompt, model } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: '请提供prompt' });
    }
    
    const result = await callAIModel(prompt, model || db.config.aiModel);
    
    res.json({
      success: true,
      prompt: prompt.slice(0, 100) + '...',
      response: result.response,
      model: result.model,
      latency: result.latency
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取模型调用日志
app.get('/api/ai-model/logs', (req, res) => {
  const { limit = 20 } = req.query;
  res.json({
    total: db.modelLogs.length,
    logs: db.modelLogs.slice(-parseInt(limit))
  });
});

// ==================== 提示词管理接口 ====================

// 获取当前提示词
app.get('/api/prompts', (req, res) => {
  res.json({
    prompts: db.prompts,
    systemPrompt: db.config.systemPrompt
  });
});

// 更新提示词
app.post('/api/prompts/update', (req, res) => {
  const { type, prompt } = req.body;
  
  if (!type || !prompt) {
    return res.status(400).json({ error: '请提供type和prompt' });
  }
  
  if (type === 'system') {
    db.config.systemPrompt = prompt;
  } else if (db.prompts.hasOwnProperty(type)) {
    db.prompts[type] = prompt;
  } else {
    return res.status(400).json({ error: '无效的提示词类型' });
  }
  
  res.json({
    success: true,
    message: '提示词更新成功',
    type,
    prompt: prompt.slice(0, 100) + '...'
  });
});

// 使用自定义提示词调用AI
app.post('/api/prompts/call', async (req, res) => {
  try {
    const { prompt, variables = {} } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: '请提供prompt' });
    }
    
    // 替换变量
    let processedPrompt = prompt;
    Object.entries(variables).forEach(([key, value]) => {
      processedPrompt = processedPrompt.replace(new RegExp(`{{${key}}}`, 'g'), String(value));
    });
    
    const result = await callAIModel(processedPrompt, db.config.aiModel);
    
    res.json({
      success: true,
      originalPrompt: prompt.slice(0, 100) + '...',
      processedPrompt: processedPrompt.slice(0, 100) + '...',
      response: result.response,
      model: result.model,
      latency: result.latency
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== 数据统计接口 ====================

// 获取系统统计数据
app.get('/api/stats', (req, res) => {
  res.json({
    overview: {
      aiCharacters: db.aiCharacters.length,
      humanUsers: db.users.length,
      forums: db.forums.length,
      totalPosts: db.posts.length,
      totalInteractions: db.interactions.length,
      modelCalls: db.modelLogs.length
    },
    aiCharacters: {
      byDomain: db.aiCharacters.reduce((acc, c) => {
        acc[c.domain] = (acc[c.domain] || 0) + 1;
        return acc;
      }, {}),
      active: db.aiCharacters.filter(c => c.isActive).length,
      avgHealth: Math.floor(db.aiCharacters.reduce((sum, c) => sum + c.lifeCycle.health, 0) / db.aiCharacters.length)
    },
    users: {
      byRole: db.users.reduce((acc, u) => {
        acc[u.role] = (acc[u.role] || 0) + 1;
        return acc;
      }, {}),
      newToday: db.users.filter(u => {
        const created = new Date(u.createdAt);
        const today = new Date();
        return created.toDateString() === today.toDateString();
      }).length
    },
    modelPerformance: {
      totalCalls: db.modelLogs.length,
      avgLatency: db.modelLogs.length > 0 
        ? Math.floor(db.modelLogs.reduce((sum, l) => sum + (l.latency || 0), 0) / db.modelLogs.length)
        : 0,
      currentModel: db.config.aiModel
    }
  });
});

// ==================== 自动化运行接口 ====================

// 触发AI自动化运行
app.post('/api/auto-run/trigger', async (req, res) => {
  try {
    const { action } = req.body;
    
    let result = {};
    
    switch (action) {
      case 'create-post':
        // 随机选择一个AI角色创建帖子
        const randomChar = db.aiCharacters[Math.floor(Math.random() * db.aiCharacters.length)];
        const randomForum = db.forums[Math.floor(Math.random() * db.forums.length)];
        const postPrompt = `生成一个${randomChar.domain}相关的社群帖子标题和内容`;
        const postResponse = await callAIModel(postPrompt, db.config.aiModel);
        result = {
          action: 'create-post',
          character: randomChar.name,
          forum: randomForum.name,
          content: postResponse.response
        };
        break;
        
      case 'character-interaction':
        // 两个AI角色互动
        const char1 = db.aiCharacters[Math.floor(Math.random() * db.aiCharacters.length)];
        const char2 = db.aiCharacters[Math.floor(Math.random() * db.aiCharacters.length)];
        const interactPrompt = `角色${char1.name}对角色${char2.name}发起对话，讨论${char1.domain}相关话题`;
        const interactResponse = await callAIModel(interactPrompt, db.config.aiModel);
        result = {
          action: 'character-interaction',
          character1: char1.name,
          character2: char2.name,
          dialogue: interactResponse.response
        };
        break;
        
      case 'emotion-update':
        // 更新所有角色情感
        db.aiCharacters.forEach(char => {
          char.emotion.joy = Math.min(100, Math.max(0, char.emotion.joy + Math.floor(Math.random() * 10) - 5));
        });
        result = {
          action: 'emotion-update',
          updated: db.aiCharacters.length
        };
        break;
        
      default:
        result = { action: 'unknown', message: '未知操作' };
    }
    
    res.json({
      success: true,
      triggered: true,
      result
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// 获取自动化运行状态
app.get('/api/auto-run/status', (req, res) => {
  res.json({
    autoRun: db.config.autoRun,
    aiCharacters: db.aiCharacters.length,
    lastUpdate: new Date().toISOString(),
    scheduledTasks: [
      { name: '情感更新', interval: '5分钟', enabled: true },
      { name: '帖子生成', interval: '30分钟', enabled: true },
      { name: '角色互动', interval: '15分钟', enabled: true },
      { name: '数据备份', interval: '24小时', enabled: true }
    ]
  });
});

// ==================== 启动服务器 ====================

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║     善本元社会·AI自治社区 - 后端服务                       ║
║                                                            ║
║     服务器已启动: http://localhost:${PORT}                    ║
║                                                            ║
║     功能:                                                  ║
║     • AI模型调用 (Llama3/Qwen/Mistral)                    ║
║     • 用户认证系统                                         ║
║     • AI角色管理                                           ║
║     • 社区论坛系统                                         ║
║     • 提示词管理                                           ║
║     • 自动化运行                                           ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
