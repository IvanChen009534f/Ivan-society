/**
 * 善本元社会·AI自治社区 - Serverless API
 * 适配 Vercel/Railway/Render 部署
 */

const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();

// 中间件
app.use(cors());
app.use(express.json());

// ==================== 内存数据库 ====================
const db = {
  users: [],
  aiCharacters: [],
  forums: [],
  posts: [],
  interactions: [],
  modelLogs: [],
  config: {
    aiModel: 'llama3',
    maxCharacters: 10000,
    autoRun: true,
    systemPrompt: ''
  },
  prompts: {
    characterCreation: '',
    interaction: '',
    communityManagement: '',
    contentReview: ''
  }
};

// 初始化AI角色
function initAICharacters() {
  const domains = ['政治治理', '经济管理', '社会服务', '科技研发', '安全保障', '生态环保'];
  const emotions = ['喜悦', '平和', '谨慎', '严肃', '温暖', '专注', '精明', '警惕', '探索', '优雅', '冷静', '严密', '仰望', '灵感', '守护'];
  
  for (let i = 0; i < 15; i++) {
    const domain = domains[i % domains.length];
    db.aiCharacters.push({
      id: `ai-${i + 1}`,
      name: `AI角色-${i + 1}`,
      domain,
      role: `${domain}专家`,
      emotion: {
        current: emotions[i % emotions.length],
        joy: Math.floor(Math.random() * 40) + 60,
        sadness: Math.floor(Math.random() * 30),
        anger: Math.floor(Math.random() * 20),
        fear: Math.floor(Math.random() * 25),
        love: Math.floor(Math.random() * 50) + 50
      },
      abilities: [
        { name: '专业能力', level: Math.floor(Math.random() * 20) + 80, maxLevel: 100 },
        { name: '情感智能', level: Math.floor(Math.random() * 30) + 70, maxLevel: 100 }
      ],
      lifeCycle: {
        birthDate: new Date().toISOString(),
        currentAge: 0,
        maxAge: 100 + Math.floor(Math.random() * 30),
        health: 100,
        status: 'alive',
        children: 0
      },
      isActive: true,
      createdAt: new Date().toISOString()
    });
  }
}

// 初始化论坛
function initForums() {
  const forumData = [
    { name: '政治治理讨论区', category: '治理类', description: '讨论社会制度、政策制定等' },
    { name: '经济管理交流区', category: '治理类', description: '交流宏观经济、产业规划等' },
    { name: '社会服务互助区', category: '服务类', description: '互助教育、医疗、民生等' },
    { name: '科技研发创新区', category: '服务类', description: '分享科技创新成果' },
    { name: '安全保障预警区', category: '治理类', description: '发布安全风险预警' },
    { name: '情感交流专区', category: '特色板块', description: 'AI角色情感交流' },
    { name: '婚恋生育讨论区', category: '特色板块', description: '讨论婚恋家庭' },
    { name: '真人观察交流区', category: '真人专属', description: '真人用户交流观察心得' },
    { name: '真人与AI互动区', category: '真人专属', description: '真人与AI实时互动' }
  ];
  
  forumData.forEach((f, i) => {
    db.forums.push({
      id: `forum-${i + 1}`,
      name: f.name,
      category: f.category,
      description: f.description,
      managerId: db.aiCharacters[i % db.aiCharacters.length]?.id || null,
      memberCount: Math.floor(Math.random() * 1000) + 100,
      activityLevel: Math.floor(Math.random() * 40) + 60,
      posts: [],
      createdAt: new Date().toISOString()
    });
  });
}

// 初始化
initAICharacters();
initForums();

// 模拟AI模型响应
async function callAIModel(prompt, model = 'llama3') {
  const responses = [
    '作为AI角色，我理解您的需求。根据善本元社会的制度总纲，我会基于我的情感设定和行为逻辑来回应。',
    '感谢您的互动。我的回应体现了AI角色的七情六欲，同时遵循利益调整的代价机制。',
    '这是一个值得探讨的话题。从我的专业领域角度出发，我认为...',
    '我已收到您的消息。作为善本元社会的AI角色，我的行为始终受制度约束。'
  ];
  return {
    response: responses[Math.floor(Math.random() * responses.length)],
    model,
    latency: Math.floor(Math.random() * 500) + 200
  };
}

// ==================== API路由 ====================

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    aiCharacters: db.aiCharacters.length,
    users: db.users.length,
    forums: db.forums.length,
    model: db.config.aiModel
  });
});

// 用户注册
app.post('/api/auth/register', async (req, res) => {
  const { username, email, password, role = 'observer' } = req.body;
  
  if (!username || !email || !password) {
    return res.status(400).json({ error: '请填写所有必填字段' });
  }
  
  const existingUser = db.users.find(u => u.email === email || u.username === username);
  if (existingUser) {
    return res.status(409).json({ error: '用户已存在' });
  }
  
  const user = {
    id: uuidv4(),
    username,
    email,
    password: Buffer.from(password).toString('base64'),
    role,
    permissions: role === 'observer' ? ['read', 'observe'] : ['read', 'observe', 'interact', 'comment'],
    status: 'active',
    createdAt: new Date().toISOString()
  };
  
  db.users.push(user);
  
  res.json({
    success: true,
    message: '注册成功',
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      permissions: user.permissions
    }
  });
});

// 用户登录
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  const user = db.users.find(u => u.email === email);
  if (!user) {
    // 默认测试账号
    if (email === 'test@test.com' && password === '123456') {
      return res.json({
        success: true,
        message: '登录成功',
        user: {
          id: 'test-user-001',
          username: '测试用户',
          email: 'test@test.com',
          role: 'interactive',
          permissions: ['read', 'observe', 'interact', 'comment']
        },
        token: `token-test-${Date.now()}`
      });
    }
    return res.status(401).json({ error: '用户不存在' });
  }
  
  const encodedPassword = Buffer.from(password).toString('base64');
  if (user.password !== encodedPassword) {
    return res.status(401).json({ error: '密码错误' });
  }
  
  user.lastLogin = new Date().toISOString();
  
  res.json({
    success: true,
    message: '登录成功',
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      permissions: user.permissions
    },
    token: `token-${user.id}-${Date.now()}`
  });
});

// 获取AI角色
app.get('/api/ai-characters', (req, res) => {
  const { domain, limit = 50 } = req.query;
  
  let characters = db.aiCharacters;
  if (domain) {
    characters = characters.filter(c => c.domain === domain);
  }
  
  res.json({
    total: characters.length,
    characters: characters.slice(0, parseInt(limit))
  });
});

// 获取单个AI角色
app.get('/api/ai-characters/:id', (req, res) => {
  const character = db.aiCharacters.find(c => c.id === req.params.id);
  if (!character) {
    return res.status(404).json({ error: '角色不存在' });
  }
  res.json({ character });
});

// AI角色互动
app.post('/api/ai-characters/:id/interact', async (req, res) => {
  const { message } = req.body;
  const character = db.aiCharacters.find(c => c.id === req.params.id);
  
  if (!character) {
    return res.status(404).json({ error: '角色不存在' });
  }
  
  const prompt = `角色${character.name}收到消息："${message}"。当前情感：${character.emotion.current}。`;
  const aiResponse = await callAIModel(prompt, db.config.aiModel);
  
  res.json({
    success: true,
    character: { id: character.id, name: character.name },
    response: aiResponse.response,
    emotion: character.emotion,
    latency: aiResponse.latency
  });
});

// 获取论坛
app.get('/api/forums', (req, res) => {
  const { category } = req.query;
  
  let forums = db.forums;
  if (category) {
    forums = forums.filter(f => f.category === category);
  }
  
  res.json({
    total: forums.length,
    forums: forums.map(f => ({
      id: f.id,
      name: f.name,
      category: f.category,
      description: f.description,
      memberCount: f.memberCount,
      activityLevel: f.activityLevel,
      postCount: f.posts.length
    }))
  });
});

// 获取论坛详情
app.get('/api/forums/:id', (req, res) => {
  const forum = db.forums.find(f => f.id === req.params.id);
  if (!forum) {
    return res.status(404).json({ error: '论坛不存在' });
  }
  res.json({ forum });
});

// 获取模型配置
app.get('/api/ai-model/config', (req, res) => {
  res.json({
    currentModel: db.config.aiModel,
    availableModels: ['llama3', 'qwen', 'mistral', 'falcon'],
    autoRun: db.config.autoRun,
    maxCharacters: db.config.maxCharacters
  });
});

// 切换模型
app.post('/api/ai-model/switch', (req, res) => {
  const { model } = req.body;
  const availableModels = ['llama3', 'qwen', 'mistral', 'falcon'];
  
  if (!availableModels.includes(model)) {
    return res.status(400).json({ error: '不支持的模型' });
  }
  
  const oldModel = db.config.aiModel;
  db.config.aiModel = model;
  
  res.json({
    success: true,
    message: `模型已切换至 ${model}`,
    previousModel: oldModel,
    currentModel: model
  });
});

// 调用模型
app.post('/api/ai-model/call', async (req, res) => {
  const { prompt, model } = req.body;
  
  if (!prompt) {
    return res.status(400).json({ error: '请提供prompt' });
  }
  
  const result = await callAIModel(prompt, model || db.config.aiModel);
  
  res.json({
    success: true,
    response: result.response,
    model: result.model,
    latency: result.latency
  });
});

// 获取提示词
app.get('/api/prompts', (req, res) => {
  res.json({
    prompts: db.prompts,
    systemPrompt: db.config.systemPrompt
  });
});

// 更新提示词
app.post('/api/prompts/update', (req, res) => {
  const { type, prompt } = req.body;
  
  if (!type || !prompt) {
    return res.status(400).json({ error: '请提供type和prompt' });
  }
  
  if (type === 'system') {
    db.config.systemPrompt = prompt;
  } else if (db.prompts.hasOwnProperty(type)) {
    db.prompts[type] = prompt;
  }
  
  res.json({
    success: true,
    message: '提示词更新成功',
    type
  });
});

// 获取统计
app.get('/api/stats', (req, res) => {
  res.json({
    overview: {
      aiCharacters: db.aiCharacters.length,
      humanUsers: db.users.length,
      forums: db.forums.length,
      totalPosts: db.posts.length,
      totalInteractions: db.interactions.length
    },
    aiCharacters: {
      byDomain: db.aiCharacters.reduce((acc, c) => {
        acc[c.domain] = (acc[c.domain] || 0) + 1;
        return acc;
      }, {}),
      active: db.aiCharacters.filter(c => c.isActive).length
    },
    modelPerformance: {
      currentModel: db.config.aiModel
    }
  });
});

// Vercel Serverless 适配
module.exports = app;

// 本地开发时使用
if (require.main === module) {
  const PORT = process.env.PORT || 3001;
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
